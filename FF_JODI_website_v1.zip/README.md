# FF JODI
Mobile-first prototype created from the requested concept.

Includes:
- Home page and category selection
- Gun-only and Gun + Character sections
- Full character library from the supplied references
- Gun search and character search
- Jodi builder
- Estimated 5-level score
- Optional character
- Save and share
- Trust/score explanation

Important: weapon/character names and scores in this prototype should be verified against current game data before public launch. Scores are FF JODI estimates, not official Garena ratings.

Production next steps:
1. Verify current game data and image/licensing rights.
2. Add real images.
3. Connect Google/Firebase authentication.
4. Add Firestore for cloud saves/history.
5. Add an admin panel for data and scoring updates.
6. Add Privacy, Terms, Contact and About pages.
7. Deploy and optimize SEO/Core Web Vitals.
